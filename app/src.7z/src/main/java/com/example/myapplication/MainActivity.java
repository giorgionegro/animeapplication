package com.example.myapplication;
import static java.lang.System.*;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    final List<List<String>> sresult = new ArrayList<>();
    final String port = "5000";
    final String server = "http://giorgionegro.chickenkiller.com:";
    public Context context;
    private String json;
    private LinearLayout ll;
    View view2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fm = getSupportFragmentManager();
                 view2 = fm.getFragments().get(0).getView();
                context = fm.getFragments().get(0).getContext();
                ll = view2.findViewWithTag("wedr");
                try {
                    new Latest(view2).execute();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                // fragment.onClicklatest(fragment.view);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.latest) {
            FragmentManager fm = getSupportFragmentManager();
            View view2 = fm.getFragments().get(0).getView();
            context = fm.getFragments().get(0).getContext();
            ll = view2.findViewWithTag("wedr");
            try {
                new Latest(view2).execute();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        return super.onOptionsItemSelected(item);
    }

    private class DownloadTask extends AsyncTask<String, Integer, String> {


        private final String currentanime;


        public DownloadTask(Context context, String currentanime) {
            this.currentanime = currentanime;
        }

        @Override
        protected String doInBackground(String... sUrl) {
            InputStream input = null;
            OutputStream output = null;
            HttpURLConnection connection;
            try {
                File directory = new File(Environment.getExternalStorageDirectory() + File.separator + "anime" + File.separator + currentanime);
                directory.mkdirs();
                URL url = new URL(sUrl[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                // expect HTTP 200 OK, so we don't mistakenly save error report
                // instead of the file
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    return "Server returned HTTP " + connection.getResponseCode()
                            + " " + connection.getResponseMessage();
                }

                // this will be useful to display download percentage
                // might be -1: server did not report the length
                int fileLength = connection.getContentLength();
                File file = new File(Environment.getExternalStorageDirectory().getPath() + "/anime/" + File.separator + currentanime + File.separator + currentanime + ".mp4");
                if(file.exists()){


                    int vlcRequestCode = 42;
                    Uri uri = Uri.parse(file.getPath());
                    Intent vlcIntent = new Intent(Intent.ACTION_VIEW);
                    vlcIntent.setDataAndTypeAndNormalize(uri, "video/*");
                    vlcIntent.putExtra("title", currentanime);
                    PackageManager packageManager = getPackageManager();
                    List<ResolveInfo> activities = packageManager.queryIntentActivities(vlcIntent,
                            PackageManager.MATCH_DEFAULT_ONLY);

                    if ( activities.size()>0){
                    startActivityForResult(vlcIntent, vlcRequestCode);}else{
                        Snackbar snackBar = Snackbar .make(view2, "An Error Occurred! missing video player", Snackbar.LENGTH_LONG) .setAction("RETRY", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                            }
                        });
                        snackBar.setActionTextColor(Color.BLUE);
                        View snackBarView = snackBar.getView();
                        TextView textView = snackBarView.findViewById(R.id.snackbar_text);
                        textView.setTextColor(Color.RED);
                        snackBar.show();
                        System.out.println("error");


                    }

                }
else{
                input = connection.getInputStream();
                output = new FileOutputStream(Environment.getExternalStorageDirectory().getPath() + "/anime/" + File.separator + currentanime + File.separator + currentanime + ".mp4");

                byte[] data = new byte[4096];
                long total = 0;
                int count;
                while ((count = input.read(data)) != -1) {
                    if (isCancelled()) {
                        input.close();
                        return null;
                    }
                    total += count;
                    // publishing the progress....
                    if (fileLength > 0) // only if total length is known
                        publishProgress((int) (total * 100 / fileLength));
                    output.write(data, 0, count);
                }}
            } catch (Exception e) {
                return e.toString();
            } finally {
                try {
                    if (output != null)
                        output.close();
                    if (input != null)
                        input.close();
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }

            if (connection != null)
                connection.disconnect();

            return null;
        }


    }

    private class Latest extends AsyncTask {
        String url2;

        public Latest(View view) {

            this.url2 = url2;

        }


        @Override

        protected Object doInBackground(Object... arg0) {
            try {
                if (Build.VERSION.SDK_INT > 22) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1);
                }
                try {
                    Thread.sleep(0);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                RequestQueue queue = Volley.newRequestQueue(context);
                String url = server + port + "/latest";

// Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                ll.removeAllViews();
                                System.out.println("sadsad");
                                json = response;
                                sresult.clear();
                                System.out.println(json);
                                try {
                                    String[] items = json.split("\\s*], \\s*");

                                    for (String i : items
                                    ) {
                                        i = i.replace("\"", "");
                                        i = i.replace("[", "" );
                                        i = i.replace("]", "");
                                        i= i.replace("Streaming & Download SUB ITA - AnimeWorld","");


                                        List<String> items2 = Arrays.asList(i.split("\\s*,\\s*"));
                                        System.out.println(i);
                                        sresult.add(items2);


                                    }
                                    List<Button> listabottoni = new ArrayList<>();
                                    for (int i = 0; i < sresult.size(); i++) {
                                        Button myButton = new Button(context);
                                        myButton.setTag(sresult.get(i).get(0));
                                        myButton.setText(sresult.get(i).get(1));
                                        myButton.setOnClickListener(new buttonlisener2());
                                        listabottoni.add(myButton);
                                    }


                                    System.out.println(ll);
                                    for (Button myButton : listabottoni
                                    ) {
                                        ll.addView(myButton);
                                    }
                                    listabottoni.clear();

                                } catch (Exception e) {

                                    System.out.println(e.toString());
                                }
                                System.out.println("asd");
                                System.out.println(sresult);

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error.getStackTrace());
                    }
                });


                stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                        1000000000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                System.out.println("sfdad");


// Add the request to the RequestQueue.
                queue.add(stringRequest);

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

       /* protected Object execute(Object... arg0) {
            try {
                if (Build.VERSION.SDK_INT > 22) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1);
                }
                try {
                    Thread.sleep(0);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                RequestQueue queue = Volley.newRequestQueue(getContext());
                String url = "http://giorgionegro.chickenkiller.com:"+port+"/q?q=a";
//Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                System.out.println("sadsad");

                                json = response;
                                System.out.println(json);
                                try {
                                    String[] items = json.split("\\s*], \\s*");
                                    for (String i : items

                                    ) {
                                        i = i.replace('[', ' ');
                                        i = i.replace(']', ' ');
                                        List<String> items2 = Arrays.asList(i.split("\\s*, \\s*"));
                                        sresult.add(items2);


                                    }
                                    newButtons();

                                } catch (Exception e) {

                                    System.out.println(e.toString());
                                }
                                System.out.println("asd");
                                System.out.println(sresult);

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error.getMessage() + "a");
                    }
                });*/
              /*  JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                        new Response.Listener<JSONObject>()
                        {
                            @Override
                            public void onResponse(JSONObject response) {
                                // display response
                               System.out.println( response.toString());
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                System.out.println(error.getMessage());
                            }
                        }
                );*/
        //  System.out.println("sfdad");


// Add the request to the RequestQueue.
        //queue.add(stringRequest);

        /*    } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }*/

    }

    public class buttonlisener2 implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            try {
                new startdownload(view).execute();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private class startdownload extends AsyncTask {
        final View view;


        public startdownload(View view) {
            this.view = view;

        }

        @Override
        protected Object doInBackground(Object... arg0) {

            Button bu = (Button) view;
            final DownloadTask downloadTask = new DownloadTask(context, bu.getText().toString());

            downloadTask.execute((String) view.getTag());
            System.out.println((String) view.getTag());


            return null;
        }

    }


}